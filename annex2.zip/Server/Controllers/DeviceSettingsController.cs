﻿using Microsoft.AspNetCore.Mvc;
using Server.Services;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DeviceSettingsController : ControllerBase
    {
        private readonly SocketsService sockets;
        public DeviceSettingsController(SocketsService sockets)
        {
            this.sockets = sockets;
        }
        [HttpGet]
        public DeviceSettings Get([FromQuery] string id)
        {
            if (DeviceSettings.All.ContainsKey(id))
                return DeviceSettings.All[id];
            return new DeviceSettings();
        }

        [HttpPost]
        public void Set([FromQuery] string id, [FromBody] DeviceSettings settings)
        {
            if (DeviceSettings.All.ContainsKey(id))
                DeviceSettings.All[id] = settings;
            else
                DeviceSettings.All.Add(id, settings);

            this.sockets.GetSocket(id)?.SendAsync(
                new byte[] { MagicNumbers.PluginChangedCode }, SocketFlags.None);
        }
    }
}
