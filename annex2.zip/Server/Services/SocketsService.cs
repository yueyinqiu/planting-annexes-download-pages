﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server.Services
{
    public class SocketsService : IDisposable
    {
        private ConcurrentDictionary<string, Socket> sockets =
            new ConcurrentDictionary<string, Socket>();
        private readonly Socket listener;
        private readonly CancellationTokenSource cancellation;

        public SocketsService()
        {
            this.cancellation = new CancellationTokenSource();
            this.listener = new Socket(SocketType.Stream, ProtocolType.Tcp);
            this.listener.Bind(new IPEndPoint(IPAddress.Loopback, MagicNumbers.SocketPort));
            this.listener.Listen(MagicNumbers.Backlog);
            _ = this.AcceptSockets(this.cancellation.Token);
        }

        public Socket GetSocket(string id)
        {
            if (!this.sockets.TryGetValue(id, out Socket result))
                return null;

            if (result.Connected)
                return result;

            this.sockets.Remove(id, out _);
            return null;
        }

        private async Task AcceptSockets(
            CancellationToken cancellationToken = default)
        {
            for (; ; )
            {
                var socket = await this.listener.AcceptAsync()
                    .ConfigureAwait(false);
                await this.SaveSockets(socket, cancellationToken).ConfigureAwait(false);
            }
        }

        private async Task SaveSockets(Socket socket,
            CancellationToken cancellationToken = default)
        {
            await socket.SendAsync(
                new byte[]{
                    MagicNumbers.PluginChangedCode
                }, SocketFlags.None, cancellationToken);

            byte[] bytes = new byte[1000];
            await socket.ReceiveAsync(bytes, SocketFlags.None, cancellationToken);

            string id = Encoding.ASCII.GetString(bytes).TrimEnd('\0');

            this.sockets?.AddOrUpdate(id, socket, (id, value) =>
            {
                value.Dispose();
                return socket;
            });
        }

        public void Dispose()
        {
            this.cancellation.Cancel();
            this.cancellation.Dispose();
            var sockets = this.sockets;
            this.sockets = null;
            this.listener.Dispose();
            foreach (var socket in sockets)
                socket.Value.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
