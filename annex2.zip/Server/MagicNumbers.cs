﻿namespace Server
{
    public static class MagicNumbers
    {
        public const int SocketPort = 8082;
        public const int Backlog = 233;
        public const int PluginChangedCode = 123;
    }
}
