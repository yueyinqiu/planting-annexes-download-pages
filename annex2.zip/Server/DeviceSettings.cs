using System;
using System.Collections.Generic;

namespace Server
{
    public class DeviceSettings
    {
        public static Dictionary<string, DeviceSettings> All { get; } = new Dictionary<string, DeviceSettings>();

        public Plugin[] Plugins { get; set; } = Array.Empty<Plugin>();
        public class Plugin
        {
            public string HardwareId { get; set; }
            public byte[] SoftwareLib { get; set; }
            public string SoftwarePluginClass { get; set; }
        }
    }
}