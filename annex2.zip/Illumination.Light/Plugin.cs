﻿using PluginApi;
using System;

namespace Illumination.Light
{
    public class Plugin : IPlugin
    {
        public Plugin() { }

        public void Start()
        {
            this.ChangeTo(true);
        }

        public event EventHandler<ValueChangeEventArgs> ValueChanged;

        private void ChangeTo(bool on)
        {
            byte[] r = new byte[] { on ? (byte)0 : (byte)1 };
            ValueChanged.Invoke(this, new ValueChangeEventArgs(r));
            Console.WriteLine($"Illumination: {(on ? "ON" : "OFF")}.");
        }

        public void Dispose()
        {
            this.ChangeTo(false);
        }
    }
}
