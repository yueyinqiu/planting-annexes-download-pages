namespace DeviceSettingsBuilder
{
    public class DeviceSettings
    {
        public Plugin[] Plugins { get; set; } = new Plugin[0];
        public class Plugin
        {
            public string HardwareId { get; set; }
            public byte[] SoftwareLib { get; set; }
            public string SoftwarePluginClass { get; set; }
        }
    }
}