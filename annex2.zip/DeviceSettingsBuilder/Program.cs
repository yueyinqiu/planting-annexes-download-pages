﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace DeviceSettingsBuilder
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            List<DeviceSettings.Plugin> plugins = new List<DeviceSettings.Plugin>();
            for (; ; )
            {
                Console.Write("Enter the SoftwareLib (or 'e' to stop):");
                string path = Console.ReadLine();
                if (path == "e") { break; }
                var plugin = new DeviceSettings.Plugin();
                plugins.Add(plugin);
                plugin.SoftwareLib = File.ReadAllBytes(path);

                Console.Write("Enter the SoftwarePluginClass:");
                plugin.SoftwarePluginClass = Console.ReadLine();

                Console.Write("Enter the HardwareId:");
                plugin.HardwareId = Console.ReadLine();
            }
            DeviceSettings deviceSettings = new DeviceSettings {
                Plugins = plugins.ToArray()
            };
            Console.WriteLine(JsonConvert.SerializeObject(deviceSettings));
            Console.ReadLine();
        }
    }
}
