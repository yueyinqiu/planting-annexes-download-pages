﻿using PluginApi;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Illumination
{
    public class Plugin : IPlugin
    {
        private readonly CancellationTokenSource tokenSource;
        public Plugin()
        {
            this.tokenSource = new CancellationTokenSource();
        }

        private static readonly TimeSpan tenSeconds = new TimeSpan(0, 0, 10);
        public void Start()
        {
            var token = this.tokenSource.Token;
            Task task = Task.Run(() =>
            {
                for (; ; )
                {
                    this.WaitAndChangeTo(true, tenSeconds, token).Wait();
                    this.WaitAndChangeTo(false, tenSeconds, token).Wait();
                }
            });
        }

        public event EventHandler<ValueChangeEventArgs> ValueChanged;

        private async Task WaitAndChangeTo(bool on,
            TimeSpan waitTime, CancellationToken token = default)
        {
            await Task.Delay(waitTime, token);
            if (token.IsCancellationRequested)
                return;
            byte[] r = new byte[] { on ? (byte)0 : (byte)1 };
            ValueChanged.Invoke(this, new ValueChangeEventArgs(r));
            Console.WriteLine($"Illumination: {(on ? "ON" : "OFF")}.");
        }

        public void Dispose()
        {
            this.tokenSource.Cancel();
            this.tokenSource.Dispose();
            this.WaitAndChangeTo(false, new TimeSpan()).Wait();
        }
    }
}