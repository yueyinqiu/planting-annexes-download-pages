﻿namespace Client
{
    public static class MagicNumbers
    {
        public const int SocketPort = 6334;
        public const int HttpPort = 6333;
        public const int Backlog = 233;
        public const int PluginChangedCode = 123;
        public const int Linking = 100;
        public const int BaudRate = 9600;
        public const int Timeout = 700000;
        public const string Id = "4ce350537ac14abe8af3d44a3558fb37";
        public const string ServerAddress = "121.4.166.134";
    }
}
