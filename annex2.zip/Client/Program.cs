﻿using Newtonsoft.Json;
using PluginApi;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Net.Http;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    internal class Program
    {
        private static readonly Dictionary<string, IPlugin> plugins = new Dictionary<string, IPlugin>();
        private static readonly Dictionary<string, SerialPort> hardwares = new Dictionary<string, SerialPort>();

        private static void Main(string[] args)
        {
            FindHardwares();
            StartListing().Wait();
        }
        private static void PrintSeparator()
        {
            Console.WriteLine("================================");
        }

        private static void FindHardwares()
        {
            byte[] linking = new byte[] { MagicNumbers.Linking };
            Console.WriteLine("Finding hardwares...");
            string[] allPorts = SerialPort.GetPortNames();
            foreach (string portName in allPorts)
            {
                SerialPort port = null;
                try
                {
                    Console.WriteLine($"Linking {portName}...");
                    port = new SerialPort(portName, MagicNumbers.BaudRate) {
                        WriteTimeout = MagicNumbers.Timeout,
                        ReadTimeout = MagicNumbers.Timeout
                    };
                    port.Open();
                    port.Write(linking, 0, 1);

                    string id;
                    for (; ;  )
                    {
                        id = port.ReadLine().Trim();
                        if (id.StartsWith("ID"))
                        {
                            id = id[2..];
                            break;
                        }
                    }
                    
                    hardwares.Add(id, port);
                    Console.WriteLine($"{portName} has been linked as {id}.");
                }
                catch
                {
                    port?.Dispose();
                    Console.WriteLine($"Error when linking {portName}. Skipped.");
                }
            }
            Console.WriteLine("Hardwares Linked.");
            PrintSeparator();
        }

        private static void SendHardware(string hardwareId, byte[] value)
        {
            if (hardwares.TryGetValue(hardwareId, out SerialPort hardware))
            {
                hardware.Write(value, 0, value.Length);
                return;
            }
            Console.WriteLine($"Hardware not found. Skipped.");
        }

        private static async Task StartListing()
        {
            using Socket socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            socket.Connect(MagicNumbers.ServerAddress, MagicNumbers.SocketPort);

            Console.WriteLine("Server Found.");
            PrintSeparator();

            socket.Send(Encoding.ASCII.GetBytes(MagicNumbers.Id));

            byte[] buffer = new byte[1];

            for (; ; )
            {
                await socket.ReceiveAsync(buffer, SocketFlags.None);

                Debug.Assert(buffer[0] == MagicNumbers.PluginChangedCode);

                Console.WriteLine("Plugin Changes Found.");
                PrintSeparator();

                await InstallNewPluginsAsync();
            }
        }

        private static async Task InstallNewPluginsAsync()
        {
            using HttpClient httpClient = new HttpClient();
            Console.WriteLine("Downloading Plugins...");
            string str = await httpClient.GetStringAsync(
                $"http://{MagicNumbers.ServerAddress}:{MagicNumbers.HttpPort}/DeviceSettings/?id={MagicNumbers.Id}");
            var q = JsonConvert.DeserializeObject<DeviceSettings>(str);
            Console.WriteLine("Completed.");
            PrintSeparator();

            Console.WriteLine("Disposing Current Plugins...");
            foreach (var p in plugins)
                p.Value.Dispose();
            plugins.Clear();
            Console.WriteLine("Completed.");
            PrintSeparator();

            Console.WriteLine("Installing Plugins...");
            int skipped = 0;
            foreach (var p in q.Plugins)
            {
                Console.WriteLine($"Loading {p.SoftwarePluginClass} for {p.HardwareId}...");
                if (!hardwares.ContainsKey(p.HardwareId.Trim()))
                {
                    Console.WriteLine($"Hardware not found. Skipped.");
                    skipped++;
                    continue;
                }
                Assembly assembly = Assembly.Load(p.SoftwareLib);
                IPlugin plugin = (IPlugin)assembly.CreateInstance(p.SoftwarePluginClass);
                plugin.ValueChanged += (sender, e) =>
                {
                    Console.WriteLine($"Value Changed to {Convert.ToBase64String(e.Value)} in Plugin {p.SoftwarePluginClass} (for {p.HardwareId}).");
                    SendHardware(p.HardwareId, e.Value);
                };
                plugins.Add(p.HardwareId, plugin);
                Console.WriteLine("Completed.");
            }
            Console.WriteLine($"All Plugins Installed ({skipped} Skipped).");
            PrintSeparator();

            Console.WriteLine("Starting Plugins...");
            foreach (var plugin in plugins)
            {
                plugin.Value.Start();
            }
            Console.WriteLine("Completed.");
            PrintSeparator();
        }
    }
}