﻿using System;

namespace PluginApi
{
    public interface IPlugin : IDisposable
    {
        event EventHandler<ValueChangeEventArgs> ValueChanged;

        void Start();
    }
}
