﻿using System;

namespace PluginApi
{
    public class ValueChangeEventArgs : EventArgs
    {
        public ValueChangeEventArgs(byte[] value) { this.Value = value; }
        public byte[] Value { get; }
    }
}
