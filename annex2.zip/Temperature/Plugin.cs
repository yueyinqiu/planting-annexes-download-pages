﻿using PluginApi;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Temperature
{
    public class Plugin : IPlugin
    {
        private readonly CancellationTokenSource tokenSource;
        public Plugin()
        {
            this.tokenSource = new CancellationTokenSource();
        }

        private static readonly TimeSpan oneMinute = new TimeSpan(0, 1, 0);
        public void Start()
        {
            var token = this.tokenSource.Token;
            Task task = Task.Run(() =>
            {
                for (; ; )
                {
                    this.WaitAndChangeTo(5, oneMinute, token).Wait();
                    this.WaitAndChangeTo(35, oneMinute, token).Wait();
                }
            });
        }

        public event EventHandler<ValueChangeEventArgs> ValueChanged;

        private async Task WaitAndChangeTo(int temperature,
            TimeSpan waitTime, CancellationToken token = default)
        {
            await Task.Delay(waitTime, token);
            if (token.IsCancellationRequested)
                return;
            int realValue = temperature + 100;
            byte[] r = new byte[] { (byte)realValue };
            ValueChanged.Invoke(this, new ValueChangeEventArgs(r));
            Console.WriteLine($"Temperature: Setting to {temperature}.");
        }

        public void Dispose()
        {
            this.tokenSource.Cancel();
            this.tokenSource.Dispose();

            byte[] r = new byte[] { 255 };
            ValueChanged.Invoke(this, new ValueChangeEventArgs(r));
        }
    }
}